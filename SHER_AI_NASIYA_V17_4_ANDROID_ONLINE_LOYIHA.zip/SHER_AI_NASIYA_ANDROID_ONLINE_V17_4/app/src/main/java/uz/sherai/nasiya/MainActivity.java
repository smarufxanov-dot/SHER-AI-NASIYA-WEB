package uz.sherai.nasiya;
import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import android.print.PrintManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
  // IMPORTANT: Upload V17.4 as index.html to this HTTPS address before building.
  private static final String APP_URL = "https://smarufxanov-dot.github.io/SHER-AI-NASIYA-WEB/";
  private WebView web;
  private ValueCallback<Uri[]> uploadCallback;
  private static final int PICK_FILE=102;
  @Override public void onCreate(Bundle state){super.onCreate(state);
    web=new WebView(this);setContentView(web);
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);s.setAllowContentAccess(true);
    s.setJavaScriptCanOpenWindowsAutomatically(true);s.setSupportMultipleWindows(false);
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
        Uri u=r.getUrl(); if("https".equals(u.getScheme()) && u.getHost()!=null && u.getHost().equals("smarufxanov-dot.github.io"))return false;
        try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception e){Toast.makeText(MainActivity.this,"Havola ochilmadi",Toast.LENGTH_SHORT).show();}return true;
      }
      @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err){
        if(req.isForMainFrame()) Toast.makeText(MainActivity.this,"Internetni tekshiring",Toast.LENGTH_LONG).show();
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){
        if(uploadCallback!=null)uploadCallback.onReceiveValue(null);uploadCallback=cb;
        try{Intent intent=params.createIntent();startActivityForResult(intent,PICK_FILE);return true;}
        catch(Exception e){uploadCallback=null;return false;}
      }
      @Override public void onPermissionRequest(PermissionRequest request){
        // Camera permission is limited to our trusted HTTPS app origin.
        if(request.getOrigin().toString().startsWith(APP_URL)){
          runOnUiThread(()->{if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.CAMERA)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            pendingPermission=request;requestPermissions(new String[]{android.Manifest.permission.CAMERA},33);
          }else request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});});
        } else request.deny();
      }
    });
    if(state==null)web.loadUrl(APP_URL);else web.restoreState(state);
  }
  private PermissionRequest pendingPermission;
  @Override public void onRequestPermissionsResult(int req,String[] perms,int[] grants){super.onRequestPermissionsResult(req,perms,grants);
    if(req==33 && pendingPermission!=null){if(grants.length>0&&grants[0]==android.content.pm.PackageManager.PERMISSION_GRANTED)pendingPermission.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});else pendingPermission.deny();pendingPermission=null;}
  }
  @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
    if(req==PICK_FILE && uploadCallback!=null){uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));uploadCallback=null;}
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
  @Override public boolean onCreateOptionsMenu(Menu menu){menu.add("Yangilash");menu.add("Chop etish / PDF");return true;}
  @Override public boolean onOptionsItemSelected(MenuItem item){
    if(item.getTitle().toString().startsWith("Yangilash")){web.reload();return true;}
    if(item.getTitle().toString().startsWith("Chop")){PrintManager p=(PrintManager)getSystemService(PRINT_SERVICE);p.print("SHER AI NASIYA",web.createPrintDocumentAdapter("SHER AI NASIYA"),null);return true;}
    return super.onOptionsItemSelected(item);
  }
}
