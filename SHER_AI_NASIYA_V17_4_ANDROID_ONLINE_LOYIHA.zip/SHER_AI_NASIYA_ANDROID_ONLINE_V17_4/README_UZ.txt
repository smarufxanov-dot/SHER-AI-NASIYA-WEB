SHER AI NASIYA — ONLINE ANDROID ILOVA LOYIHASI (V17.4)

1. SHER_AI_NASIYA_V17_4_HAR_JADVALDA_ITOG.html faylini GitHub Pages repozitoriyingizga index.html nomi bilan yuklang.
2. https://smarufxanov-dot.github.io/SHER-AI-NASIYA-WEB/ manzilida aynan V17.4 ochilishini tekshiring.
3. Ushbu papkani Android Studio orqali Open Project qiling. Android SDK 35 va JDK 17 kerak.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) tanlang.
5. APK: app/build/outputs/apk/debug/app-debug.apk

Bu ZIP tayyor APK emas, Android Studio loyihasidir. Ushbu muhitda Android SDK/Gradle yo'q, shuning uchun APK kompilyatsiya qilinmadi.

MUHIM CHEKLOVLAR:
- Online ilova internetdagi GitHub Pages HTML sahifasini WebViewda ochadi.
- Hozirgi HTML localStorage dan foydalanadi. Kassir va admin qurilmalari o'rtasida umumiy baza YO'Q.
- Haqiqiy admin/kassir rollari va xavfsiz server avtorizatsiyasi hali kerak.
- Brauzerdagi eski localStorage APKga avtomatik o'tmaydi.
- Chop etish uchun Android menyusidagi 'Chop etish / PDF' dan foydalaning; HTML window.open hisobotlari WebViewda qo'shimcha moslashtirish talab qilishi mumkin.
- Ushbu manba kod sinov uchun, ishlab chiqarishga tayyor deb hisoblanmasin.
